# Something Wants You To Sit And Watch

Minecraft Forge 1.20.1 mod source project.

## Latest source changes

- The mansion basement entrance is a full-height hinged door. The old trapdoor registry
  entry and saved landmark key are retained so earlier saves can migrate.
- The village now has three distinct house presets and a post-tour home choice. The
  selected village home is furnished and unlocked; choosing to build independently
  lets the player claim a nearby bed as their respawn point.
- Village building footprints are spaced to avoid intersecting house shells. The
  three available presets have different roof silhouettes and facade details.
- Mansion construction begins immediately after the village tour, and its roof and
  chimney have been refined.
- Smug Bro's arm pivots are moved to the shoulder joints. Perry's lower-leg segments
  now inherit their parent-leg swing. The imported female-fan mesh and Perry mesh
  binaries remain unchanged.
- The couch raid temporarily removes only decorative blocks and restores them when
  the event ends (including after a story reset).
- Selected objectives have been rewritten in more natural player-facing language.
- The source version is 1.1.0. The GitHub Actions workflow validates resource JSON,
  validates the 64 basement-door blockstate combinations, and builds the release
  artifact as `Sit-and-watch.jar` with Java 17 / Gradle 8.1.1.

## Build

Use the repository's `.github/workflows/build.yml` workflow, or run `gradle build --no-daemon` with JDK 17 and Gradle 8.1.1.

## Integrated features in this source package

- LuxuryLighting dynamic item lighting is integrated into the Sit and Watch JAR. Held and dropped light-emitting block-items provide client-side local light.
- First-time joining players receive one torch and one spyglass.
- New Overworld worlds use a fixed Plains biome source; existing generated chunks are not retroactively replaced.
- `COPYRIGHT.txt` is placed at the JAR root, with an additional nested ownership notice and per-model metadata/sidecar notices.
- The release artifact name is always `Sit-and-watch.jar` (no version in the file name).

The original uploaded LuxuryLighting source archive contained only the compiled JAR, so its small dynamic-lighting class was recreated from the supplied bytecode and its LevelRenderer Mixin/refmap were retained.
