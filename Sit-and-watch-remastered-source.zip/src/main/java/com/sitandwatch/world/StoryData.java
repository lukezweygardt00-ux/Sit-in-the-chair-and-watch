package com.sitandwatch.world;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.LongTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.level.saveddata.SavedData;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** Persistent progress of the story (Day 1 .. Night 4) for this world. */
public class StoryData extends SavedData {
    public static final String NAME = "sitandwatch_story";

    // progression
    public boolean started;
    public long startDay;
    @Nullable public UUID player, smug, ron, perry, watcher;

    // one-shot flags
    public boolean couchPlacedFlag, partyEjected;
    public boolean fansConverted, smugSpawned, mansionBuilt, perrySpawned, perryBetrayed, ronSpawned, partyDone, ronStuffed,
            couchUnzipped, ronWoke, dismissive, mobStarted, mobDone, night4Prepared, climaxStarted, climaxDone;
    public boolean mansionTourOffered, mansionTourStarted, mansionTourDone, night4LightsDimmed;
    public boolean basementDistortionActive, couchRaidStarted, couchRaidDone;
    public final List<BlockPos> couchRaidPositions = new ArrayList<>();
    public final List<String> couchRaidBlockIds = new ArrayList<>();
    public int mansionTourStep, couchRaidHits, couchRaidBlocksRemoved;
    public long mansionTourStart, couchRaidStart;

    // mega village + Smug Bro's Day 1 tour and the post-tour home choice
    public boolean villageBuilt, tourArrived, tourComplete, tourClockReset;
    public boolean homeChoiceDone, homeChoicePrompted, customHomeChosen, customHomeClaimed;
    public final List<BlockPos> houseChoiceDoors = new ArrayList<>();
    public final List<BlockPos> houseChoiceBeds = new ArrayList<>();
    public int tourIdx;
    public long tourStopTick;

    // Smug Bro mansion appears one vertical layer at a time during the post-tour sequence.
    public int mansionBuildLayer = -8;
    public long mansionBuildLastTick;

    // Last objective sent to the client, to avoid re-sending the same HUD packet every second.
    public String guideKey = "";
    public int guideX, guideZ;
    public boolean guideHasTarget;

    // Night 4 stealth sequence: 0 = approach, 1 = Smug Bro has spotted the player.
    public int night4StealthPhase, night4PatrolIndex;
    public long night4LastSeen, night4ResetTick;
    @Nullable public BlockPos night4LastKnown;
    public final Set<Long> lockedVillageDoors = new HashSet<>();
    @Nullable public BlockPos villageCenter;
    public final List<BlockPos> tour = new ArrayList<>();

    // small state machines
    public int phase;          // Smug Bro's current activity on Day 1
    public int lurePhase;      // Day 2 party
    public int day3Phase;      // Day 3 frame-up
    public long phaseStart, lastGrab, unzipTick, partyStart, mobStart;
    public boolean smugEscortActive;
    public long smugEscortStart, lastSmugEscort;
    @Nullable public BlockPos smugEscortDestination;
    public int mobHits;
    public int climaxTick;

    // places
    @Nullable public BlockPos home, site, doorPos, partyPos, trapdoor, chair, ronSpot, smugRoom, couch, square, ringCenter;
    @Nullable public BlockPos basementMin, basementMax;
    public Direction couchFacing = Direction.NORTH;
    public final List<BlockPos> barrier = new ArrayList<>();
    public final Set<Long> lockedTrapdoors = new HashSet<>();

    public StoryData() { }

    public static StoryData load(CompoundTag t) {
        StoryData d = new StoryData();
        d.started = t.getBoolean("started");
        d.startDay = t.getLong("startDay");
        d.player = uuid(t, "player"); d.smug = uuid(t, "smug"); d.ron = uuid(t, "ron");
        d.perry = uuid(t, "perry"); d.watcher = uuid(t, "watcher");
        d.couchPlacedFlag = t.getBoolean("couchPlacedFlag");
        d.partyEjected = t.getBoolean("partyEjected");
        d.fansConverted = t.getBoolean("fansConverted"); d.smugSpawned = t.getBoolean("smugSpawned");
        d.mansionBuilt = t.getBoolean("mansionBuilt"); d.perrySpawned = t.getBoolean("perrySpawned"); d.perryBetrayed = t.getBoolean("perryBetrayed");
        d.ronSpawned = t.getBoolean("ronSpawned"); d.partyDone = t.getBoolean("partyDone");
        d.ronStuffed = t.getBoolean("ronStuffed"); d.couchUnzipped = t.getBoolean("couchUnzipped");
        d.ronWoke = t.getBoolean("ronWoke"); d.dismissive = t.getBoolean("dismissive");
        d.mobStarted = t.getBoolean("mobStarted"); d.mobDone = t.getBoolean("mobDone");
        d.night4Prepared = t.getBoolean("night4Prepared"); d.climaxStarted = t.getBoolean("climaxStarted");
        d.climaxDone = t.getBoolean("climaxDone");
        d.mansionTourOffered = t.getBoolean("mansionTourOffered");
        d.mansionTourStarted = t.getBoolean("mansionTourStarted");
        d.mansionTourDone = t.getBoolean("mansionTourDone");
        d.night4LightsDimmed = t.getBoolean("night4LightsDimmed");
        d.basementDistortionActive = t.getBoolean("basementDistortionActive");
        d.couchRaidStarted = t.getBoolean("couchRaidStarted");
        d.couchRaidDone = t.getBoolean("couchRaidDone");
        d.mansionTourStep = t.getInt("mansionTourStep");
        d.couchRaidHits = t.getInt("couchRaidHits");
        d.couchRaidBlocksRemoved = t.getInt("couchRaidBlocksRemoved");
        d.mansionTourStart = t.getLong("mansionTourStart");
        d.couchRaidStart = t.getLong("couchRaidStart");
        for (Tag e : t.getList("couchRaidStolen", Tag.TAG_COMPOUND)) {
            CompoundTag stolen = (CompoundTag) e;
            d.couchRaidPositions.add(BlockPos.of(stolen.getLong("pos")));
            d.couchRaidBlockIds.add(stolen.getString("block"));
        }
        d.phase = t.getInt("phase"); d.lurePhase = t.getInt("lurePhase"); d.day3Phase = t.getInt("day3Phase");
        d.day3FlirtStarted = t.getBoolean("day3FlirtStarted");
        d.day3AskedSmugAboutRon = t.getBoolean("day3AskedSmugAboutRon");
        d.phaseStart = t.getLong("phaseStart"); d.lastGrab = t.getLong("lastGrab"); d.unzipTick = t.getLong("unzipTick");
        d.partyStart = t.getLong("partyStart"); d.mobStart = t.getLong("mobStart");
        d.smugEscortActive = t.getBoolean("smugEscortActive");
        d.smugEscortStart = t.getLong("smugEscortStart"); d.lastSmugEscort = t.getLong("lastSmugEscort");
        d.smugEscortDestination = pos(t, "smugEscortDestination");
        d.mobHits = t.getInt("mobHits"); d.climaxTick = t.getInt("climaxTick");
        d.home = pos(t, "home"); d.site = pos(t, "site"); d.doorPos = pos(t, "doorPos"); d.partyPos = pos(t, "partyPos");
        d.trapdoor = pos(t, "trapdoor"); d.chair = pos(t, "chair"); d.ronSpot = pos(t, "ronSpot");
        d.smugRoom = pos(t, "smugRoom"); d.couch = pos(t, "couch"); d.square = pos(t, "square");
        d.ringCenter = pos(t, "ringCenter"); d.basementMin = pos(t, "bmin"); d.basementMax = pos(t, "bmax");
        d.couchFacing = Direction.from3DDataValue(t.getInt("couchFacing"));
        if (d.couchFacing.getAxis().isVertical()) d.couchFacing = Direction.NORTH;
        d.villageBuilt = t.getBoolean("villageBuilt"); d.tourArrived = t.getBoolean("tourArrived");
        d.tourComplete = t.getBoolean("tourComplete");
        d.tourClockReset = t.getBoolean("tourClockReset");
        d.homeChoiceDone = t.getBoolean("homeChoiceDone");
        d.homeChoicePrompted = t.getBoolean("homeChoicePrompted");
        d.customHomeChosen = t.getBoolean("customHomeChosen");
        d.customHomeClaimed = t.getBoolean("customHomeClaimed");
        for (Tag e : t.getList("houseChoiceDoors", Tag.TAG_LONG)) d.houseChoiceDoors.add(BlockPos.of(((LongTag) e).getAsLong()));
        for (Tag e : t.getList("houseChoiceBeds", Tag.TAG_LONG)) d.houseChoiceBeds.add(BlockPos.of(((LongTag) e).getAsLong()));
        // Existing worlds already had a designated home. Preserve it instead of presenting a new menu.
        if (!t.contains("homeChoiceDone") && d.home != null) d.homeChoiceDone = true;
        d.tourIdx = t.getInt("tourIdx"); d.tourStopTick = t.getLong("tourStopTick");
        d.mansionBuildLayer = t.contains("mansionBuildLayer") ? t.getInt("mansionBuildLayer") : -8;
        d.mansionBuildLastTick = t.getLong("mansionBuildLastTick");
        d.guideKey = t.getString("guideKey"); d.guideX = t.getInt("guideX"); d.guideZ = t.getInt("guideZ");
        d.guideHasTarget = t.getBoolean("guideHasTarget");
        d.night4StealthPhase = t.getInt("night4StealthPhase");
        d.night4PatrolIndex = t.getInt("night4PatrolIndex");
        d.night4LastSeen = t.getLong("night4LastSeen");
        d.night4ResetTick = t.getLong("night4ResetTick");
        d.night4LastKnown = pos(t, "night4LastKnown");
        d.villageCenter = pos(t, "villageCenter");
        for (Tag e : t.getList("lockedVillageDoors", Tag.TAG_LONG)) d.lockedVillageDoors.add(((LongTag) e).getAsLong());
        for (Tag e : t.getList("tour", Tag.TAG_LONG)) d.tour.add(BlockPos.of(((LongTag) e).getAsLong()));
        if (!t.contains("tourComplete") && (d.phase > 1 || (!d.tour.isEmpty() && d.tourIdx >= d.tour.size()))) {
            d.tourComplete = true;
            // Preserve the existing timeline for saves that were already past the opening tour.
            d.tourClockReset = true;
        }
        for (Tag e : t.getList("barrier", Tag.TAG_LONG)) d.barrier.add(BlockPos.of(((LongTag) e).getAsLong()));
        for (Tag e : t.getList("locked", Tag.TAG_LONG)) d.lockedTrapdoors.add(((LongTag) e).getAsLong());
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag t) {
        t.putBoolean("started", started); t.putLong("startDay", startDay);
        putUuid(t, "player", player); putUuid(t, "smug", smug); putUuid(t, "ron", ron);
        putUuid(t, "perry", perry); putUuid(t, "watcher", watcher);
        t.putBoolean("couchPlacedFlag", couchPlacedFlag);
        t.putBoolean("partyEjected", partyEjected);
        t.putBoolean("fansConverted", fansConverted); t.putBoolean("smugSpawned", smugSpawned);
        t.putBoolean("mansionBuilt", mansionBuilt); t.putBoolean("perrySpawned", perrySpawned); t.putBoolean("perryBetrayed", perryBetrayed);
        t.putBoolean("ronSpawned", ronSpawned); t.putBoolean("partyDone", partyDone);
        t.putBoolean("ronStuffed", ronStuffed); t.putBoolean("couchUnzipped", couchUnzipped);
        t.putBoolean("ronWoke", ronWoke); t.putBoolean("dismissive", dismissive);
        t.putBoolean("mobStarted", mobStarted); t.putBoolean("mobDone", mobDone);
        t.putBoolean("night4Prepared", night4Prepared); t.putBoolean("climaxStarted", climaxStarted);
        t.putBoolean("climaxDone", climaxDone);
        t.putBoolean("mansionTourOffered", mansionTourOffered);
        t.putBoolean("mansionTourStarted", mansionTourStarted);
        t.putBoolean("mansionTourDone", mansionTourDone);
        t.putBoolean("night4LightsDimmed", night4LightsDimmed);
        t.putBoolean("basementDistortionActive", basementDistortionActive);
        t.putBoolean("couchRaidStarted", couchRaidStarted);
        t.putBoolean("couchRaidDone", couchRaidDone);
        t.putInt("mansionTourStep", mansionTourStep);
        t.putInt("couchRaidHits", couchRaidHits);
        t.putInt("couchRaidBlocksRemoved", couchRaidBlocksRemoved);
        t.putLong("mansionTourStart", mansionTourStart);
        t.putLong("couchRaidStart", couchRaidStart);
        ListTag stolen = new ListTag();
        for (int i = 0; i < Math.min(couchRaidPositions.size(), couchRaidBlockIds.size()); i++) {
            CompoundTag entry = new CompoundTag();
            entry.putLong("pos", couchRaidPositions.get(i).asLong());
            entry.putString("block", couchRaidBlockIds.get(i));
            stolen.add(entry);
        }
        t.put("couchRaidStolen", stolen);
        t.putInt("phase", phase); t.putInt("lurePhase", lurePhase); t.putInt("day3Phase", day3Phase);
        t.putBoolean("day3FlirtStarted", day3FlirtStarted);
        t.putBoolean("day3AskedSmugAboutRon", day3AskedSmugAboutRon);
        t.putLong("phaseStart", phaseStart); t.putLong("lastGrab", lastGrab); t.putLong("unzipTick", unzipTick);
        t.putLong("partyStart", partyStart); t.putLong("mobStart", mobStart);
        t.putBoolean("smugEscortActive", smugEscortActive);
        t.putLong("smugEscortStart", smugEscortStart); t.putLong("lastSmugEscort", lastSmugEscort);
        putPos(t, "smugEscortDestination", smugEscortDestination);
        t.putInt("mobHits", mobHits); t.putInt("climaxTick", climaxTick);
        putPos(t, "home", home); putPos(t, "site", site); putPos(t, "doorPos", doorPos); putPos(t, "partyPos", partyPos);
        putPos(t, "trapdoor", trapdoor); putPos(t, "chair", chair); putPos(t, "ronSpot", ronSpot);
        putPos(t, "smugRoom", smugRoom); putPos(t, "couch", couch); putPos(t, "square", square);
        putPos(t, "ringCenter", ringCenter); putPos(t, "bmin", basementMin); putPos(t, "bmax", basementMax);
        t.putInt("couchFacing", couchFacing.get3DDataValue());
        t.putBoolean("villageBuilt", villageBuilt); t.putBoolean("tourArrived", tourArrived);
        t.putBoolean("tourComplete", tourComplete); t.putBoolean("tourClockReset", tourClockReset);
        t.putBoolean("homeChoiceDone", homeChoiceDone); t.putBoolean("homeChoicePrompted", homeChoicePrompted);
        t.putBoolean("customHomeChosen", customHomeChosen); t.putBoolean("customHomeClaimed", customHomeClaimed);
        ListTag choiceDoors = new ListTag();
        for (BlockPos p : houseChoiceDoors) choiceDoors.add(LongTag.valueOf(p.asLong()));
        t.put("houseChoiceDoors", choiceDoors);
        ListTag choiceBeds = new ListTag();
        for (BlockPos p : houseChoiceBeds) choiceBeds.add(LongTag.valueOf(p.asLong()));
        t.put("houseChoiceBeds", choiceBeds);
        t.putInt("tourIdx", tourIdx); t.putLong("tourStopTick", tourStopTick);
        t.putInt("mansionBuildLayer", mansionBuildLayer); t.putLong("mansionBuildLastTick", mansionBuildLastTick);
        t.putString("guideKey", guideKey); t.putInt("guideX", guideX); t.putInt("guideZ", guideZ);
        t.putBoolean("guideHasTarget", guideHasTarget);
        t.putInt("night4StealthPhase", night4StealthPhase);
        t.putInt("night4PatrolIndex", night4PatrolIndex);
        t.putLong("night4LastSeen", night4LastSeen);
        t.putLong("night4ResetTick", night4ResetTick);
        putPos(t, "night4LastKnown", night4LastKnown);
        putPos(t, "villageCenter", villageCenter);
        ListTag doors = new ListTag();
        for (long door : lockedVillageDoors) doors.add(LongTag.valueOf(door));
        t.put("lockedVillageDoors", doors);
        ListTag tl = new ListTag();
        for (BlockPos p : tour) tl.add(LongTag.valueOf(p.asLong()));
        t.put("tour", tl);
        ListTag b = new ListTag();
        for (BlockPos p : barrier) b.add(LongTag.valueOf(p.asLong()));
        t.put("barrier", b);
        ListTag l = new ListTag();
        for (long p : lockedTrapdoors) l.add(LongTag.valueOf(p));
        t.put("locked", l);
        return t;
    }

    public void reset() {
        StoryData fresh = new StoryData();
        started = fresh.started; startDay = 0; player = smug = ron = perry = watcher = null;
        couchPlacedFlag = false; partyEjected = false;
        fansConverted = smugSpawned = mansionBuilt = perrySpawned = perryBetrayed = ronSpawned = partyDone = ronStuffed = couchUnzipped = false;
        ronWoke = dismissive = mobStarted = mobDone = night4Prepared = climaxStarted = climaxDone = false;
        phase = lurePhase = day3Phase = mobHits = climaxTick = 0;
        mansionTourOffered = mansionTourStarted = mansionTourDone = night4LightsDimmed = false;
        basementDistortionActive = couchRaidStarted = couchRaidDone = false;
        mansionTourStep = couchRaidHits = couchRaidBlocksRemoved = 0;
        mansionTourStart = couchRaidStart = 0;
        couchRaidPositions.clear(); couchRaidBlockIds.clear();
        day3FlirtStarted = day3AskedSmugAboutRon = false;
        phaseStart = lastGrab = unzipTick = partyStart = mobStart = 0;
        smugEscortActive = false; smugEscortStart = lastSmugEscort = 0; smugEscortDestination = null;
        home = site = doorPos = partyPos = trapdoor = chair = ronSpot = smugRoom = couch = square = ringCenter = null;
        basementMin = basementMax = null;
        barrier.clear();
        lockedTrapdoors.clear(); lockedVillageDoors.clear();
        villageBuilt = tourArrived = tourComplete = tourClockReset = false; tourIdx = 0; tourStopTick = 0; villageCenter = null; tour.clear();
        homeChoiceDone = homeChoicePrompted = customHomeChosen = customHomeClaimed = false;
        houseChoiceDoors.clear(); houseChoiceBeds.clear();
        mansionBuildLayer = -8; mansionBuildLastTick = 0; guideKey = ""; guideX = guideZ = 0; guideHasTarget = false;
        night4StealthPhase = night4PatrolIndex = 0;
        night4LastSeen = night4ResetTick = 0; night4LastKnown = null;
        setDirty();
    }

    private static UUID uuid(CompoundTag t, String k) { return t.hasUUID(k) ? t.getUUID(k) : null; }
    private static void putUuid(CompoundTag t, String k, @Nullable UUID u) { if (u != null) t.putUUID(k, u); }
    private static BlockPos pos(CompoundTag t, String k) { return t.contains(k, Tag.TAG_LONG) ? BlockPos.of(t.getLong(k)) : null; }
    private static void putPos(CompoundTag t, String k, @Nullable BlockPos p) { if (p != null) t.putLong(k, p.asLong()); }
}
