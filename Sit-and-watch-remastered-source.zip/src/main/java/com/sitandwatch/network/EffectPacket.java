package com.sitandwatch.network;

import com.sitandwatch.client.ClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Misc client effects for the ending. */
public class EffectPacket {
    public static final int BLOOD = 0, AMBIENCE_START = 1, AMBIENCE_STOP = 2, FADE_OUT = 3, FADE_IN = 4, BASEMENT_DISTORTION = 5;
    public final int type, arg;

    public EffectPacket(int type, int arg) { this.type = type; this.arg = arg; }

    public static void encode(EffectPacket m, FriendlyByteBuf b) { b.writeInt(m.type); b.writeInt(m.arg); }

    public static EffectPacket decode(FriendlyByteBuf b) { return new EffectPacket(b.readInt(), b.readInt()); }

    public static void handle(EffectPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientState.effect(m.type, m.arg)));
        ctx.get().setPacketHandled(true);
    }
}
