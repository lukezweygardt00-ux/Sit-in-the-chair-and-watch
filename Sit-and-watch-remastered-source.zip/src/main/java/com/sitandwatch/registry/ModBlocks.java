package com.sitandwatch.registry;

import com.sitandwatch.SitAndWatch;
import com.sitandwatch.block.*;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, SitAndWatch.MOD_ID);

    public static final RegistryObject<Block> ZIPPER_COUCH = BLOCKS.register("zipper_couch", () ->
            new ZipperCouchBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BROWN).strength(0.8f).sound(SoundType.WOOL).noOcclusion()));
    public static final RegistryObject<Block> WORKING_TV = BLOCKS.register("working_tv", () ->
            new WorkingTvBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK).strength(1.0f).lightLevel(s -> 8).sound(SoundType.METAL)));
    public static final RegistryObject<Block> SMUG_STATUE = BLOCKS.register("smug_statue", () ->
            new SmugStatueBlock(BlockBehaviour.Properties.of().mapColor(MapColor.GOLD).strength(2.0f).sound(SoundType.METAL)));
    public static final RegistryObject<Block> LUXURY_BED = BLOCKS.register("luxury_bed", () ->
            new LuxuryBedBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_RED).strength(0.6f).sound(SoundType.WOOL)));
    public static final RegistryObject<Block> WOODEN_CHAIR = BLOCKS.register("wooden_chair", () ->
            new WoodenChairBlock(BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(1.0f).sound(SoundType.WOOD).noOcclusion()));
    /** Legacy block retained so worlds created by 1.0.9 can load and migrate their old entrance. */
    public static final RegistryObject<Block> BASEMENT_TRAPDOOR = BLOCKS.register("basement_trapdoor", () ->
            new BasementTrapdoorBlock(BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(3.0f).sound(SoundType.WOOD).noOcclusion(), BlockSetType.OAK));
    public static final RegistryObject<Block> BASEMENT_DOOR = BLOCKS.register("basement_door", () ->
            new BasementDoorBlock(BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(3.0f)
                    .sound(SoundType.WOOD).noOcclusion().pushReaction(net.minecraft.world.level.material.PushReaction.DESTROY),
                    BlockSetType.SPRUCE));
}
