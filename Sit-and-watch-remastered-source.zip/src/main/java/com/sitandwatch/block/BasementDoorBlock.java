package com.sitandwatch.block;

import com.sitandwatch.world.StoryManager;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.phys.BlockHitResult;

/**
 * The mansion's basement entrance is a full-height hinged door. The story locks
 * the lower half until Night 4; the normal DoorBlock interaction handles opening
 * and closing once the story permits access.
 */
public class BasementDoorBlock extends DoorBlock {
    public BasementDoorBlock(Properties properties, BlockSetType type) {
        super(properties, type);
    }

    public static BlockPos lowerPos(BlockState state, BlockPos clickedPos) {
        return state.getValue(HALF) == DoubleBlockHalf.UPPER ? clickedPos.below() : clickedPos;
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level instanceof ServerLevel serverLevel) {
            BlockPos lower = lowerPos(state, pos);
            if (StoryManager.isBasementDoorLocked(serverLevel, lower)) {
                level.playSound(null, lower, SoundEvents.CHEST_LOCKED, SoundSource.BLOCKS, 0.9f, 0.7f);
                if (player instanceof ServerPlayer serverPlayer) {
                    serverPlayer.displayClientMessage(Component.literal("It won't open."), true);
                    StoryManager.onBasementDoorAttempt(serverLevel, lower, serverPlayer);
                }
                return InteractionResult.CONSUME;
            }
        }
        return super.use(state, level, pos, player, hand, hit);
    }
}
