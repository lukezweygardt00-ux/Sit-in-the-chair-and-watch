package com.sitandwatch.block;

import com.sitandwatch.registry.ModSounds;
import com.sitandwatch.world.StoryManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;

/** Couch. On Day 3 the story sets has_zipper=true; right-clicking then unzips it and ejects Ron. */
public class ZipperCouchBlock extends HorizontalDirectionalBlock {
    private static final VoxelShape SHAPE = Shapes.or(
            Block.box(2, 0, 3, 4, 3, 5), Block.box(12, 0, 3, 14, 3, 5),
            Block.box(2, 0, 11, 4, 3, 13), Block.box(12, 0, 11, 14, 3, 13),
            Block.box(1, 3, 2, 15, 7, 15), Block.box(3, 6, 5, 13, 9, 14),
            Block.box(2, 7, 2, 14, 15, 5), Block.box(0, 6, 4, 3, 13, 15),
            Block.box(13, 6, 4, 16, 13, 15));

    public static final BooleanProperty HAS_ZIPPER = BooleanProperty.create("has_zipper");
    public static final BooleanProperty UNZIPPED = BooleanProperty.create("unzipped");

    public ZipperCouchBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(HAS_ZIPPER, false).setValue(UNZIPPED, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<net.minecraft.world.level.block.Block, BlockState> b) {
        b.add(FACING, HAS_ZIPPER, UNZIPPED);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection().getOpposite());
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (state.getValue(HAS_ZIPPER) && !state.getValue(UNZIPPED)) {
            if (!level.isClientSide && level instanceof ServerLevel sl) {
                if (!StoryManager.canUnzipCouch(sl)) {
                    player.displayClientMessage(net.minecraft.network.chat.Component.translatable("sitandwatch.message.ask_smug_first"), true);
                    return InteractionResult.CONSUME;
                }
                level.setBlock(pos, state.setValue(UNZIPPED, true), 3);
                level.playSound(null, pos, ModSounds.ZIPPER.get(), SoundSource.BLOCKS, 1.5f, 1.0f);
                StoryManager.onCouchUnzipped(sl, pos, state.getValue(FACING));
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }
}
