package com.sitandwatch.event;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.sitandwatch.entity.SocialVillagerEntity;
import com.sitandwatch.block.BasementDoorBlock;
import com.sitandwatch.entity.SmugBroEntity;
import com.sitandwatch.network.CameraLockPacket;
import com.sitandwatch.network.ModNetwork;
import com.sitandwatch.network.GuidePacket;
import com.sitandwatch.world.StoryData;
import com.sitandwatch.world.StoryManager;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.sounds.SoundEvents;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.EntityMountEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.entity.player.PlayerSleepInBedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class ForgeEvents {
    /** Nobody sleeps through Night 3 / Night 4. */
    @SubscribeEvent
    public void onSleep(PlayerSleepInBedEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        if (StoryManager.noSleep(p.serverLevel())) {
            e.setResult(Player.BedSleepingProblem.NOT_POSSIBLE_NOW);
            p.displayClientMessage(Component.translatable("sitandwatch.message.cannot_sleep"), true);
            return;
        }
        StoryManager.claimCustomHome(p, e.getPos());
    }


    /** Villager homes stay shut; the player's own home is deliberately not in the locked set. */
    @SubscribeEvent
    public void onVillageDoorUse(PlayerInteractEvent.RightClickBlock e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || e.getLevel().isClientSide) return;
        BlockState state = e.getLevel().getBlockState(e.getPos());
        if (!(state.getBlock() instanceof DoorBlock)) return;

        var lowerPos = state.getValue(DoorBlock.HALF) == DoubleBlockHalf.UPPER
                ? e.getPos().below() : e.getPos();
        if (!StoryManager.isVillageDoorLocked(p.serverLevel(), lowerPos)) return;

        e.setCanceled(true);
        e.setCancellationResult(InteractionResult.FAIL);
        p.displayClientMessage(Component.literal("This is not your house. You cannot enter."), true);
        p.playSound(SoundEvents.CHEST_LOCKED, 0.8f, 0.8f);
    }

    /** On Day 3, talking to Smug Bro starts the search-for-Ron conversation. */
    @SubscribeEvent
    public void onAskSmugAboutRon(PlayerInteractEvent.EntityInteract e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || e.getLevel().isClientSide
                || !(e.getTarget() instanceof SmugBroEntity smug)) return;
        if (StoryManager.onAskSmugAboutRon(p.serverLevel(), p, smug)) {
            e.setCanceled(true);
            e.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    /** Locked village doors and the basement entrance cannot be broken to bypass story gates. */
    @SubscribeEvent
    public void onLockedStoryBlockBreak(BlockEvent.BreakEvent e) {
        if (!(e.getPlayer() instanceof ServerPlayer p)) return;
        BlockState state = e.getState();
        if (state.getBlock() instanceof DoorBlock) {
            BlockPos lowerPos = state.getValue(DoorBlock.HALF) == DoubleBlockHalf.UPPER
                    ? e.getPos().below() : e.getPos();
            if (state.getBlock() instanceof BasementDoorBlock) {
                e.setCanceled(true);
                p.displayClientMessage(Component.literal("The basement door won't budge."), true);
                return;
            }
            if (StoryManager.isVillageDoorLocked(p.serverLevel(), lowerPos)) {
                e.setCanceled(true);
                p.displayClientMessage(Component.literal("This is not your house. You cannot enter."), true);
                p.playSound(SoundEvents.CHEST_LOCKED, 0.8f, 0.8f);
                return;
            }
        }
        if (state.getBlock() instanceof TrapDoorBlock
                && StoryManager.isTrapdoorLocked(p.serverLevel(), e.getPos())) {
            e.setCanceled(true);
            p.displayClientMessage(Component.literal("This is locked."), true);
            p.playSound(SoundEvents.CHEST_LOCKED, 0.8f, 0.8f);
        }
    }

    /** The player cannot leave the chair during the ending. */
    @SubscribeEvent
    public void onMount(EntityMountEvent e) {
        if (e.isDismounting() && e.getEntityMounting() instanceof ServerPlayer p && StoryManager.isLocked(p)) {
            e.setCanceled(true);
        }
    }

    /** Fighting the mob off on Night 3. */
    @SubscribeEvent
    public void onHurt(LivingHurtEvent e) {
        if (e.getEntity() instanceof SocialVillagerEntity && e.getSource().getEntity() instanceof ServerPlayer p) {
            StoryManager.onFanHurt(p.serverLevel());
        }
    }

    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;

        // One-time starter items. This also grants the kit to existing saves on their next login.
        if (!p.getPersistentData().getBoolean("sitandwatch_starter_kit_given")) {
            p.getInventory().add(new ItemStack(Items.TORCH));
            p.getInventory().add(new ItemStack(Items.SPYGLASS));
            p.getPersistentData().putBoolean("sitandwatch_starter_kit_given", true);
        }

        StoryData d = StoryManager.data(p.serverLevel());
        if (d.started && d.player != null && d.player.equals(p.getUUID())) {
            ModNetwork.sendTo(p, new GuidePacket(d.guideKey, d.guideX, d.guideZ, d.guideHasTarget));
            if (d.tourComplete && !d.homeChoiceDone && !d.customHomeChosen) StoryManager.sendHomeChoicePrompt(p);
        }
        if (StoryManager.isLocked(p)) {
            ModNetwork.sendTo(p, new CameraLockPacket(true, 180f, 3f));
        }
    }


    @SubscribeEvent
    public void onPlayerClone(PlayerEvent.Clone e) {
        if (e.getOriginal().getPersistentData().getBoolean("sitandwatch_starter_kit_given")) {
            e.getEntity().getPersistentData().putBoolean("sitandwatch_starter_kit_given", true);
        }
    }

    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("sitandwatch")
                .then(Commands.literal("home").requires(s -> s.getEntity() instanceof ServerPlayer)
                        .then(Commands.literal("village").then(Commands.argument("choice", IntegerArgumentType.integer(1, 3))
                                .executes(c -> {
                                    ServerPlayer p = c.getSource().getPlayerOrException();
                                    int choice = IntegerArgumentType.getInteger(c, "choice");
                                    if (StoryManager.chooseVillageHome(p, choice)) {
                                        c.getSource().sendSuccess(() -> Component.literal("Village House " + choice + " is yours."), false);
                                    } else {
                                        c.getSource().sendFailure(Component.literal("That house choice is not available right now."));
                                    }
                                    return 1;
                                })))
                        .then(Commands.literal("build").executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            if (StoryManager.beginCustomHome(p)) {
                                c.getSource().sendSuccess(() -> Component.literal("Build your home nearby, then sleep in its bed."), false);
                            } else {
                                c.getSource().sendFailure(Component.literal("The home choice is not available right now."));
                            }
                            return 1;
                        })))
                .then(Commands.literal("release").requires(s -> s.hasPermission(2)).executes(c -> {
                    ServerLevel sl = c.getSource().getServer().overworld();
                    StoryData d = StoryManager.data(sl);
                    ServerPlayer p = d.player == null ? null : (ServerPlayer) sl.getPlayerByUUID(d.player);
                    StoryManager.release(sl, d, p);
                    c.getSource().sendSuccess(() -> Component.translatable("sitandwatch.message.released"), true);
                    return 1;
                }))
                .then(Commands.literal("reset").requires(s -> s.hasPermission(2)).executes(c -> {
                    ServerLevel sl = c.getSource().getServer().overworld();
                    StoryData d = StoryManager.data(sl);
                    StoryManager.restoreCouchRaidDecorations(sl, d);
                    d.reset();
                    d.started = false;
                    c.getSource().sendSuccess(() -> Component.literal("Story reset."), true);
                    return 1;
                }))
                .then(Commands.literal("stage").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("n", IntegerArgumentType.integer(1, 8)).executes(c -> {
                            ServerLevel sl = c.getSource().getServer().overworld();
                            StoryData d = StoryManager.data(sl);
                            int n = IntegerArgumentType.getInteger(c, "n") - 1;
                            long curDay = sl.getDayTime() / 24000L;
                            d.startDay = curDay - n / 2;
                            sl.setDayTime(curDay * 24000L + (n % 2 == 1 ? 13000L : 1000L));
                            d.setDirty();
                            c.getSource().sendSuccess(() -> Component.literal("Jumped to stage " + (n + 1) + " (1=Day1, 2=Night1 ... 8=Night4)"), true);
                            return 1;
                        }))));
    }
}
