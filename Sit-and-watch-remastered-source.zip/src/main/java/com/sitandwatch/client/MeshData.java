package com.sitandwatch.client;

import com.sitandwatch.SitAndWatch;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;

import java.io.DataInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Pre-baked triangle meshes converted from the Blockbench models (assets/sitandwatch/meshes/NAME.bin).
 * File layout (big endian): int partCount; per part: UTF-prefixed(short) name, 3 float pivot (model px),
 * int vertexCount, then vertexCount * 8 floats (x, y, z, u, v, nx, ny, nz). Coordinates are in
 * vanilla ModelPart space (y down, feet at y=24), scaled so the model is exactly 32 px = 2 blocks tall.
 */
public class MeshData {
    public static class Part {
        public String name;
        public float px, py, pz;      // pivot in blocks
        public float[] v;             // 8 floats per vertex, positions already divided by 16
        public int count;
    }

    private static final Map<String, MeshData> CACHE = new HashMap<>();
    public final List<Part> parts = new ArrayList<>();

    public static void clear() { CACHE.clear(); }

    public static MeshData get(String name) {
        MeshData d = CACHE.get(name);
        if (d != null) return d;
        try {
            ResourceLocation loc = new ResourceLocation(SitAndWatch.MOD_ID, "meshes/" + name + ".bin");
            try (InputStream in = Minecraft.getInstance().getResourceManager().getResource(loc).orElseThrow().open();
                 DataInputStream din = new DataInputStream(new java.io.BufferedInputStream(in, 1 << 16))) {
                d = new MeshData();
                int partCount = din.readInt();
                for (int i = 0; i < partCount; i++) {
                    Part p = new Part();
                    int len = din.readUnsignedShort();
                    byte[] nb = new byte[len];
                    din.readFully(nb);
                    p.name = new String(nb, java.nio.charset.StandardCharsets.UTF_8);
                    p.px = din.readFloat() / 16f;
                    p.py = din.readFloat() / 16f;
                    p.pz = din.readFloat() / 16f;
                    p.count = din.readInt();
                    p.v = new float[p.count * 8];
                    for (int k = 0; k < p.count; k++) {
                        int o = k * 8;
                        p.v[o] = din.readFloat() / 16f;
                        p.v[o + 1] = din.readFloat() / 16f;
                        p.v[o + 2] = din.readFloat() / 16f;
                        p.v[o + 3] = din.readFloat();
                        p.v[o + 4] = din.readFloat();
                        p.v[o + 5] = din.readFloat();
                        p.v[o + 6] = din.readFloat();
                        p.v[o + 7] = din.readFloat();
                    }
                    d.parts.add(p);
                }
            }
        } catch (Exception e) {
            com.mojang.logging.LogUtils.getLogger().error("Failed to load mesh {}", name, e);
            d = new MeshData(); // empty so we do not retry every frame
        }
        CACHE.put(name, d);
        return d;
    }
}
