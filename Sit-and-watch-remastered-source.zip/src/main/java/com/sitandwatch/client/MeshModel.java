package com.sitandwatch.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.sitandwatch.entity.StoryVillager;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

/** Generic model that draws a baked Blockbench mesh and animates it per named part. */
public class MeshModel<T extends StoryVillager> extends EntityModel<T> {
    private final String meshName;
    private float headYaw, headPitch, limb, limbAmt, age;
    private int gesture, pose;
    private float poseProgress;

    public MeshModel(String meshName) {
        super(RenderType::entityCutoutNoCull);
        this.meshName = meshName;
    }

    @Override
    public void setupAnim(T e, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.limb = limbSwing;
        this.limbAmt = limbSwingAmount;
        this.age = ageInTicks;
        this.headYaw = netHeadYaw * Mth.DEG_TO_RAD;
        this.headPitch = headPitch * Mth.DEG_TO_RAD;
        this.gesture = e.getGesture();
        this.pose = e.getPoseState();
        this.poseProgress = e.getPoseProgress(0f, 40);
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        MeshData data = MeshData.get(meshName);
        float[] rot = new float[5]; // xRot, yRot, zRot, dx, dy
        float shake = pose == StoryVillager.P_SHIVER ? Mth.sin(age * 3.3f) * 0.045f
                : pose == StoryVillager.P_PANIC ? Mth.sin(age * 5.8f) * 0.08f : 0f;
        // Ron's panic animation shakes the complete imported mesh, not just one body part.
        ps.pushPose();
        if (pose == StoryVillager.P_SHIVER) {
            ps.translate(Mth.sin(age * 4.2f) * 0.025f, Math.abs(Mth.sin(age * 6.4f)) * 0.018f, Mth.cos(age * 3.8f) * 0.025f);
            ps.mulPose(new Quaternionf().rotationZYX(Mth.sin(age * 3.8f) * 0.065f, 0f, Mth.cos(age * 4.1f) * 0.055f));
        }
        if (pose == StoryVillager.P_PANIC) {
            ps.translate(Mth.sin(age * 5.1f) * 0.075f,
                    Math.abs(Mth.sin(age * 10.4f)) * 0.045f,
                    Mth.cos(age * 5.7f) * 0.075f);
            ps.mulPose(new Quaternionf().rotationZYX(
                    Mth.sin(age * 6.1f) * 0.24f,
                    Mth.sin(age * 8.3f) * 0.28f,
                    Mth.cos(age * 5.4f) * 0.23f));
        }
        for (MeshData.Part p : data.parts) {
            animate(p.name, rot);
            ps.pushPose();
            ps.translate(p.px + rot[3] + shake, p.py + rot[4], p.pz);
            if (rot[0] != 0f || rot[1] != 0f || rot[2] != 0f) {
                ps.mulPose(new Quaternionf().rotationZYX(rot[2], rot[1], rot[0]));
            }
            ps.translate(-p.px, -p.py, -p.pz);
            PoseStack.Pose last = ps.last();
            Matrix4f m = last.pose();
            Matrix3f n = last.normal();
            float[] v = p.v;
            // The entity render types draw QUADS, so each baked triangle is sent as a quad whose last
            // corner is repeated. Sending bare triangles scrambles every vertex after the first triangle,
            // which smears the texture across the model like strings.
            for (int i = 0; i + 2 < p.count; i += 3) {
                emit(vc, m, n, v, i * 8, light, overlay, r, g, b, a);
                emit(vc, m, n, v, (i + 1) * 8, light, overlay, r, g, b, a);
                emit(vc, m, n, v, (i + 2) * 8, light, overlay, r, g, b, a);
                emit(vc, m, n, v, (i + 2) * 8, light, overlay, r, g, b, a);
            }
            ps.popPose();
        }
        ps.popPose();
    }

    private static void emit(VertexConsumer vc, Matrix4f m, Matrix3f n, float[] v, int o, int light, int overlay,
                             float r, float g, float b, float a) {
        vc.vertex(m, v[o], v[o + 1], v[o + 2]).color(r, g, b, a).uv(v[o + 3], v[o + 4])
                .overlayCoords(overlay).uv2(light).normal(n, v[o + 5], v[o + 6], v[o + 7]).endVertex();
    }

    private void animate(String part, float[] o) {
        o[0] = o[1] = o[2] = o[3] = o[4] = 0f;
        float t = age;
        float walk = Mth.clamp(limbAmt, 0f, 1f);
        switch (part) {
            case "head" -> {
                o[1] = headYaw + Mth.sin(t * 0.045f) * 0.012f;
                o[0] = headPitch + Mth.sin(t * 0.075f) * 0.010f;
                o[2] = Mth.sin(t * 0.052f) * 0.016f;
                if (pose == StoryVillager.P_SHIVER) {
                    o[0] += 0.22f + Mth.sin(t * 5.2f) * 0.045f;
                    o[2] += Mth.sin(t * 4.4f) * 0.055f;
                }
                if (pose == StoryVillager.P_FAINTED) {
                    o[0] += 0.62f;
                    o[2] += Mth.sin(t * 0.09f) * 0.018f;
                }
                if (pose == StoryVillager.P_TRAPPED) {
                    o[0] += 0.35f + Mth.sin(t * 0.22f) * 0.025f;
                    o[2] += Mth.sin(t * 0.16f) * 0.035f;
                }
                if (pose == StoryVillager.P_GETTING_UP) {
                    o[0] += 0.6f * (1f - poseProgress);
                }
                if (gesture == StoryVillager.G_LAUGH) {
                    o[0] += -0.34f + Math.abs(Mth.sin(t * 1.8f)) * 0.25f;
                    o[2] += Mth.sin(t * 1.1f) * 0.06f;
                }
                if (gesture == StoryVillager.G_ANGRY) o[0] += 0.18f + Mth.sin(t * 2.2f) * 0.035f;
                if (gesture == StoryVillager.G_DANCE) {
                    o[0] += Mth.sin(t * 0.65f) * 0.16f;
                    o[1] += Mth.sin(t * 0.42f) * 0.22f;
                }
            }
            case "body" -> {
                // Gentle breathing at rest; the torso follows the weight shifts of each gesture.
                o[0] = Mth.sin(t * 0.11f) * 0.012f;
                o[2] = Mth.cos(t * 0.075f) * 0.009f;
                o[4] = Mth.sin(t * 0.22f) * 0.012f;
                if (walk > 0.05f) {
                    o[0] += Mth.sin(limb * 0.6662f * 2f) * 0.055f * walk;
                    o[2] += Mth.sin(limb * 0.6662f) * 0.035f * walk;
                    o[4] += Math.abs(Mth.cos(limb * 0.6662f * 2f)) * 0.018f * walk;
                }
                if (gesture == StoryVillager.G_LAUGH) {
                    o[0] += -0.10f + Math.abs(Mth.sin(t * 1.8f)) * 0.16f;
                    o[2] += Mth.sin(t * 1.8f) * 0.075f;
                    o[4] += Math.abs(Mth.sin(t * 1.8f)) * 0.025f;
                } else if (gesture == StoryVillager.G_DANCE) {
                    o[2] += Mth.sin(t * 0.55f) * 0.18f;
                    o[4] += Math.abs(Mth.sin(t * 0.55f)) * 0.045f;
                } else if (gesture == StoryVillager.G_STEAL) {
                    o[0] = -0.14f;
                    o[2] = Mth.sin(t * 0.8f) * 0.06f;
                } else if (pose == StoryVillager.P_SHIVER) {
                    o[2] += Mth.sin(t * 5.2f) * 0.04f;
                }
            }
            case "rleg" -> {
                o[0] = Mth.cos(limb * 0.6662f) * 1.08f * walk;
                if (pose == StoryVillager.P_TRAPPED) o[0] += Mth.sin(t * 0.18f) * 0.07f;
                if (gesture == StoryVillager.G_DANCE) o[0] += Mth.sin(t * 0.7f) * 0.45f;
            }
            case "lleg" -> {
                o[0] = Mth.cos(limb * 0.6662f + Mth.PI) * 1.08f * walk;
                if (pose == StoryVillager.P_TRAPPED) o[0] += Mth.sin(t * 0.18f + 1f) * 0.07f;
                if (gesture == StoryVillager.G_DANCE) o[0] += Mth.sin(t * 0.7f + Mth.PI) * 0.45f;
            }
            case "rarm" -> {
                switch (gesture) {
                    case StoryVillager.G_WAVE -> { o[0] = -2.35f; o[2] = -0.12f + Mth.sin(t * 0.62f) * 0.52f; }
                    case StoryVillager.G_POINT -> { o[0] = -1.48f; o[2] = -0.08f; }
                    case StoryVillager.G_FLEX -> { o[0] = -0.75f; o[2] = -0.92f; }
                    case StoryVillager.G_GRAB -> { o[0] = -1.25f; o[2] = -0.25f; }
                    case StoryVillager.G_LAUGH -> { o[0] = -0.42f + Mth.sin(t * 1.8f) * 0.22f; o[2] = -0.22f; }
                    case StoryVillager.G_ANGRY -> { o[0] = -1.1f + Mth.sin(t * 2.0f) * 0.25f; o[2] = -0.12f; }
                    case StoryVillager.G_DANCE -> { o[0] = -2.1f + Mth.sin(t * 0.6f) * 0.2f; o[2] = -0.75f + Mth.sin(t * 0.5f) * 0.35f; }
                    case StoryVillager.G_STEAL -> { o[0] = -1.75f + Mth.sin(t * 1.2f) * 0.12f; o[2] = -0.3f; }
                    default -> {
                        o[0] = Mth.sin(limb * 0.6662f) * 0.65f * walk;
                        o[2] = -0.025f + Mth.sin(t * 0.08f) * 0.018f;
                    }
                }
                if (pose == StoryVillager.P_GETTING_UP) {
                    o[0] = -1.15f * (1f - poseProgress);
                    o[2] = -0.22f * (1f - poseProgress);
                }
            }
            case "larm" -> {
                switch (gesture) {
                    case StoryVillager.G_WAVE -> { o[0] = -2.25f; o[2] = 0.12f + Mth.sin(t * 0.62f + 1f) * 0.50f; }
                    case StoryVillager.G_FLEX -> { o[0] = -0.75f; o[2] = 0.92f; }
                    case StoryVillager.G_LAUGH -> { o[0] = -0.42f + Mth.sin(t * 1.8f + 1f) * 0.22f; o[2] = 0.22f; }
                    case StoryVillager.G_ANGRY -> { o[0] = -1.1f + Mth.sin(t * 2.0f + 2f) * 0.25f; o[2] = 0.12f; }
                    case StoryVillager.G_DANCE -> { o[0] = -2.1f + Mth.sin(t * 0.6f + 2f) * 0.2f; o[2] = 0.75f + Mth.sin(t * 0.5f + 1f) * 0.35f; }
                    case StoryVillager.G_STEAL -> { o[0] = -1.72f + Mth.sin(t * 1.2f + 1f) * 0.12f; o[2] = 0.3f; }
                    default -> {
                        o[0] = Mth.sin(limb * 0.6662f + Mth.PI) * 0.65f * walk;
                        o[2] = 0.025f + Mth.sin(t * 0.08f + 1f) * 0.018f;
                    }
                }
                if (pose == StoryVillager.P_GETTING_UP) {
                    o[0] = -1.15f * (1f - poseProgress);
                    o[2] = 0.22f * (1f - poseProgress);
                }
            }
            case "arms" -> {
                if (gesture == StoryVillager.G_DANCE) o[2] = Mth.sin(t * 0.55f) * 0.12f;
                else if (gesture == StoryVillager.G_LAUGH) o[4] = -Math.abs(Mth.sin(t * 1.8f)) * 0.035f;
                else if (pose == StoryVillager.P_TRAPPED) o[0] = Mth.sin(t * 0.22f) * 0.055f;
                else o[2] = Mth.sin(t * 0.09f) * 0.012f;
            }
            default -> { }
        }
    }
}
