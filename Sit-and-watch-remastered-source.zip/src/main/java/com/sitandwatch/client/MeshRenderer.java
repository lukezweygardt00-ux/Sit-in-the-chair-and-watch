package com.sitandwatch.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.sitandwatch.SitAndWatch;
import com.sitandwatch.entity.StoryVillager;
import net.minecraft.ChatFormatting;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

public class MeshRenderer<T extends StoryVillager> extends MobRenderer<T, MeshModel<T>> {
    private static final String SYMBOLS = "!@#$%&*?+=~^<>";
    private final ResourceLocation texture;

    public MeshRenderer(EntityRendererProvider.Context ctx, String meshName, String textureName, float shadow) {
        super(ctx, new MeshModel<T>(meshName), shadow);
        this.texture = new ResourceLocation(SitAndWatch.MOD_ID, "textures/entity/" + textureName + ".png");
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return texture;
    }

    @Override
    protected void setupRotations(T e, PoseStack ps, float bob, float yBodyRot, float partialTick) {
        super.setupRotations(e, ps, bob, yBodyRot, partialTick);
        if (e.getPoseState() == StoryVillager.P_FAINTED || e.getPoseState() == StoryVillager.P_SHIVER) {
            // Ron remains on the floor while shaking or unconscious.
            ps.translate(0.0, 0.28, 0.0);
            float angle = e.getPoseState() == StoryVillager.P_SHIVER ? -84.0f : -90.0f;
            ps.mulPose(Axis.XP.rotationDegrees(angle));
        } else if (e.getPoseState() == StoryVillager.P_GETTING_UP) {
            // Ease smoothly from the lying pose to an upright stance over two seconds.
            float p = e.getPoseProgress(partialTick, 40);
            float eased = p * p * (3.0f - 2.0f * p);
            ps.translate(0.0, 0.28f * (1.0f - eased), 0.0);
            ps.mulPose(Axis.XP.rotationDegrees(-90.0f * (1.0f - eased)));
        }
    }

    @Override
    public void render(T e, float yaw, float partialTick, PoseStack ps, MultiBufferSource buf, int light) {
        super.render(e, yaw, partialTick, ps, buf, light);
        if (e.getTalkTicks() > 0) {
            StringBuilder sb = new StringBuilder();
            int seed = e.getId() * 31 + (e.tickCount / 4);
            for (int i = 0; i < 6; i++) sb.append(SYMBOLS.charAt(Math.floorMod(seed * 7 + i * 13 + i * i, SYMBOLS.length())));
            this.renderNameTag(e, Component.literal(sb.toString()).withStyle(ChatFormatting.OBFUSCATED), ps, buf, light);
        }
    }

    @Override
    protected boolean shouldShowName(T e) {
        return false;
    }
}
