package com.sitandwatch.client;

import com.sitandwatch.SitAndWatch;
import com.sitandwatch.entity.SmugBroEntity;
import com.sitandwatch.entity.SocialVillagerEntity;
import com.sitandwatch.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

@Mod.EventBusSubscriber(modid = SitAndWatch.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class ClientEvents {
    private static boolean crowdActive;
    private static float crowdVolume;
    private static LoopingSound theme;
    private static int starCooldown = 100;
    private static final java.util.List<ShootingStar> shootingStars = new java.util.ArrayList<>();

    private static final class ShootingStar {
        double x, y, z, vx, vy, vz;
        int life = 22;
        ShootingStar(double x, double y, double z, double vx, double vy, double vz) {
            this.x=x; this.y=y; this.z=z; this.vx=vx; this.vy=vy; this.vz=vz;
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        ClientState.tick();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) {
            ClientState.locked = false;
            ClientState.mapReady = false;
            return;
        }
        if (ClientState.locked) {
            p.setYRot(ClientState.lockYaw);
            p.setXRot(ClientState.lockPitch);
            p.yRotO = ClientState.lockYaw;
            p.xRotO = ClientState.lockPitch;
            p.yHeadRot = ClientState.lockYaw;
            p.yHeadRotO = ClientState.lockYaw;
            p.yBodyRot = ClientState.lockYaw;
            p.yBodyRotO = ClientState.lockYaw;
        }
        if (p.tickCount % 10 == 0) {
            updateCrowd(mc, p);
            ClientState.refreshMinimap(mc);
        }
        updateNightSky(mc, p);
        if (crowdActive && (theme == null || theme.isStopped())) {
            theme = new LoopingSound(ModSounds.SMUG_THEME.get(), SoundSource.MUSIC, () -> crowdActive, () -> crowdVolume);
            mc.getSoundManager().play(theme);
        }
    }

    /** Low-cost ambient shooting stars and a subtle indigo night fog for the village sequence. */
    private static void updateNightSky(Minecraft mc, LocalPlayer p) {
        long time = mc.level.getDayTime() % 24000L;
        boolean night = time >= 12500L && time < 23000L;
        if (!night) { shootingStars.clear(); starCooldown = 100; return; }
        RandomSource random = mc.level.random;
        if (--starCooldown <= 0 && shootingStars.size() < 2) {
            double x = p.getX() + random.nextDouble() * 42.0 - 21.0;
            double z = p.getZ() + random.nextDouble() * 42.0 - 21.0;
            double y = p.getY() + 24.0 + random.nextDouble() * 14.0;
            double vx = (random.nextBoolean() ? 1.0 : -1.0) * (0.38 + random.nextDouble() * 0.24);
            double vz = (random.nextBoolean() ? 1.0 : -1.0) * (0.12 + random.nextDouble() * 0.16);
            shootingStars.add(new ShootingStar(x, y, z, vx, -0.025, vz));
            starCooldown = 110 + random.nextInt(150);
        }
        var it = shootingStars.iterator();
        while (it.hasNext()) {
            ShootingStar star = it.next();
            // Draw a short bright trail behind each moving star.
            for (int i = 0; i < 4; i++) {
                mc.level.addParticle(ParticleTypes.END_ROD,
                        star.x - star.vx * i * 0.72, star.y - star.vy * i * 0.72, star.z - star.vz * i * 0.72,
                        0.0, 0.0, 0.0);
            }
            star.x += star.vx; star.y += star.vy; star.z += star.vz;
            if (--star.life <= 0) it.remove();
        }
    }

    /** The happy theme only plays while fans are circling Smug Bro, not while walking around with him. */
    private static void updateCrowd(Minecraft mc, LocalPlayer p) {
        crowdActive = false;
        crowdVolume = 0f;
        List<SmugBroEntity> smugs = mc.level.getEntitiesOfClass(SmugBroEntity.class, p.getBoundingBox().inflate(48));
        for (SmugBroEntity s : smugs) {
            int fans = mc.level.getEntitiesOfClass(SocialVillagerEntity.class, s.getBoundingBox().inflate(9.0), SocialVillagerEntity::isObsessed).size();
            if (fans >= 3) {
                crowdActive = true;
                crowdVolume = Math.max(crowdVolume, Mth.clamp(1.0f - (float) p.distanceTo(s) / 48f, 0.08f, 1.0f));
            }
        }
    }

    @SubscribeEvent
    public static void onNightFog(ViewportEvent.ComputeFogColor e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        long time = mc.level.getDayTime() % 24000L;
        if (time >= 12500L && time < 23000L) {
            e.setRed(0.22f);
            e.setGreen(0.18f);
            e.setBlue(0.34f);
        }
    }

    @SubscribeEvent
    public static void onInput(MovementInputUpdateEvent e) {
        if (!ClientState.locked) return;
        var in = e.getInput();
        in.forwardImpulse = 0f;
        in.leftImpulse = 0f;
        in.up = in.down = in.left = in.right = false;
        in.jumping = false;
        in.shiftKeyDown = false;
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles e) {
        if (ClientState.locked) {
            e.setYaw(ClientState.lockYaw);
            e.setPitch(ClientState.lockPitch);
            e.setRoll(0f);
        } else if (ClientState.basementDistortion) {
            Minecraft mc = Minecraft.getInstance();
            float tick = mc.player != null ? mc.player.tickCount : 0f;
            e.setRoll(Mth.sin(tick * 0.075f) * 0.45f);
        }
    }
}
