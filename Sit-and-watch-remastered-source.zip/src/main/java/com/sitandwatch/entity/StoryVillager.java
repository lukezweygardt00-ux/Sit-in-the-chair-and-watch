package com.sitandwatch.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

/**
 * Shared base for every humanoid in the mod (Smug Bro, Ron, the fans, the Watcher).
 * Animation state (gesture / pose) is synced to clients through SynchedEntityData; the story
 * manager drives movement through {@link #setMoveTarget(Vec3, double)}.
 */
public abstract class StoryVillager extends PathfinderMob {
    public static final int G_NONE = 0, G_WAVE = 1, G_LAUGH = 2, G_POINT = 3, G_FLEX = 4, G_GRAB = 5, G_ANGRY = 6, G_DANCE = 7, G_STEAL = 8;
    public static final int P_NORMAL = 0, P_SHIVER = 1, P_FAINTED = 2, P_TRAPPED = 3, P_PANIC = 4, P_GETTING_UP = 5;

    private static final EntityDataAccessor<Integer> GESTURE = SynchedEntityData.defineId(StoryVillager.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> POSE_STATE = SynchedEntityData.defineId(StoryVillager.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> POSE_START_TICK = SynchedEntityData.defineId(StoryVillager.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> TALK = SynchedEntityData.defineId(StoryVillager.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> OBSESSED = SynchedEntityData.defineId(StoryVillager.class, EntityDataSerializers.BOOLEAN);

    @Nullable private Vec3 moveTarget;
    private double moveSpeed = 1.0;
    private int gestureTicks;

    protected StoryVillager(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        if (this.getNavigation() instanceof GroundPathNavigation nav) {
            nav.setCanOpenDoors(true);
            nav.setCanFloat(true);
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.5)
                .add(Attributes.FOLLOW_RANGE, 48.0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MoveToTargetGoal(this));
        this.goalSelector.addGoal(2, new OpenDoorGoal(this, false));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 8.0f));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(GESTURE, 0);
        this.entityData.define(POSE_STATE, 0);
        this.entityData.define(POSE_START_TICK, 0);
        this.entityData.define(TALK, 0);
        this.entityData.define(OBSESSED, false);
    }

    // ---- synced animation state -------------------------------------------------------------
    public int getGesture() { return this.entityData.get(GESTURE); }
    public int getPoseState() { return this.entityData.get(POSE_STATE); }
    public int getTalkTicks() { return this.entityData.get(TALK); }
    public boolean isObsessed() { return this.entityData.get(OBSESSED); }
    public void setObsessed(boolean b) { this.entityData.set(OBSESSED, b); }
    public void setPoseState(int p) {
        if (this.entityData.get(POSE_STATE) != p) {
            this.entityData.set(POSE_STATE, p);
            this.entityData.set(POSE_START_TICK, this.tickCount);
        }
    }
    public int getPoseAge() { return Math.max(0, this.tickCount - this.entityData.get(POSE_START_TICK)); }
    public float getPoseProgress(float partialTick, int duration) {
        return net.minecraft.util.Mth.clamp((getPoseAge() + partialTick) / (float) Math.max(1, duration), 0.0f, 1.0f);
    }

    public void setGesture(int g, int ticks) {
        this.entityData.set(GESTURE, g);
        this.gestureTicks = ticks;
    }

    /** Play this character's voice and show floating gibberish above its head. */
    public void talk() {
        SoundEvent s = talkSound();
        if (s == null || level().isClientSide) return;
        this.entityData.set(TALK, 40);
        this.playSound(s, 1.0f, 1.0f);
    }

    @Nullable protected SoundEvent talkSound() { return null; }

    // ---- movement driven by the story -------------------------------------------------------
    public void setMoveTarget(@Nullable Vec3 pos, double speed) {
        this.moveTarget = pos;
        this.moveSpeed = speed;
    }
    public void clearMoveTarget() { this.moveTarget = null; this.getNavigation().stop(); }
    @Nullable public Vec3 getMoveTarget() { return moveTarget; }
    public double getMoveSpeed() { return moveSpeed; }
    public boolean hasMoveTarget() { return moveTarget != null; }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!level().isClientSide) {
            if (gestureTicks > 0 && --gestureTicks == 0) setGesture(G_NONE, 0);
            int t = this.entityData.get(TALK);
            if (t > 0) this.entityData.set(TALK, t - 1);
            if (talkSound() != null && getPoseState() != P_FAINTED && this.random.nextInt(320) == 0) talk();
        }
    }

    @Override
    public boolean removeWhenFarAway(double d) { return false; }

    @Override
    protected SoundEvent getHurtSound(DamageSource src) { return SoundEvents.VILLAGER_HURT; }

    @Override
    protected SoundEvent getDeathSound() { return SoundEvents.VILLAGER_DEATH; }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("PoseState", getPoseState());
        tag.putInt("PoseStartTick", this.entityData.get(POSE_START_TICK));
        tag.putBoolean("Obsessed", isObsessed());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setPoseState(tag.getInt("PoseState"));
        if (tag.contains("PoseStartTick")) this.entityData.set(POSE_START_TICK, tag.getInt("PoseStartTick"));
        setObsessed(tag.getBoolean("Obsessed"));
    }

    /** Walks toward the story-assigned target. */
    private static class MoveToTargetGoal extends Goal {
        private final StoryVillager mob;
        private int cooldown;

        MoveToTargetGoal(StoryVillager mob) {
            this.mob = mob;
            this.setFlags(java.util.EnumSet.of(Flag.MOVE));
        }

        @Override public boolean canUse() { return mob.moveTarget != null; }
        @Override public boolean canContinueToUse() { return mob.moveTarget != null; }

        @Override
        public void tick() {
            Vec3 t = mob.moveTarget;
            if (t == null) return;
            if (mob.position().distanceToSqr(t) < 2.0) {
                mob.moveTarget = null;
                mob.getNavigation().stop();
                return;
            }
            if (--cooldown <= 0) {
                cooldown = 10;
                mob.getNavigation().moveTo(t.x, t.y, t.z, mob.moveSpeed);
            }
        }
    }
}
